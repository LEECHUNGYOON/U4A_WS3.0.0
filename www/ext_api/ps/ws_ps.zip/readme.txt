﻿
#### 작업전 주의사항!! ####

    powershell 로직을 고치면 반드시 ps 폴더 내의 전체 소스를 zip으로 만들어야함!!

    Workspace 실행 시 인트로에서 해당 zip 파일을 UserData에 압축 푸는 로직이 있음!!